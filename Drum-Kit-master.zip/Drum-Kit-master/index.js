
var soundUrl = "";
//detecting button clicks

var buttons = document.querySelectorAll(".drum");
for(var i = 0; i < buttons.length; ++i){
    
    buttons[i].addEventListener("click", function() {
        
        makeSound(this.innerHTML);
        
        buttonAnimation(this.innerHTML);
        
    });
}

//detecting keyboard press

document.addEventListener("keypress", function(event) {
    
    makeSound(event.key);
    
    buttonAnimation(event.key);
    
});

//playing sound based on key pressed 
function makeSound(currentKey) {
    
    switch(currentKey){
            
        case "w":
            soundUrl = "tom-1.mp3";
            break;
            
        case "a":
            soundUrl = "tom-2.mp3";
            break;
            
        case "s":
            soundUrl = "tom-3.mp3";
            break;
            
        case "d":
            soundUrl = "tom-4.mp3";
            break;
            
        case "j":
            soundUrl = "snare.mp3";
            break;
            
        case "k":
            soundUrl = "crash.mp3";
            break;
            
        case "l":
            soundUrl = "kick-bass.mp3";
            break;
            
        default:
    }
    
    playSound();
    
}

function playSound() {
    
    var audio = new Audio(soundUrl);
    audio.play();
    
}

function buttonAnimation(currentKey){
    
    var activeButton = document.querySelector("." + currentKey);
    
    activeButton.classList.add("pressed");
    
    setTimeout(function(){
        activeButton.classList.remove("pressed");
    }, 100);
}
